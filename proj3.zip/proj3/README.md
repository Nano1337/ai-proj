# AI Project 1

Members: 
- Haoli Yin
- Lydia Liu
- Richard Song
- Shreya Reddy

Please refer to `main.py` for all requirements. 